import 'package:fake_store/screens/home.dart';
import 'package:fake_store/screens/login_screen.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      title: "My First App",
      home: LoginScreen(),
    )
    );
}

       